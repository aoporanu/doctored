@extends('Frontend::layouts.frontend')
@section('content')
<link rel="stylesheet" href="/frontend/maps.css">
  <script src="/frontend/maps.js"></script>
<div class="no-padding col-sm-12 text-center doct_1">
 
  <div id="map-container-google-1" class="z-depth-1-half map-container">
  <div class="loc_sec">
    <h1>There’s a doctor nearby</h1>

    <form>
  
    <div class="row">
      <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12  autocomplete2">
        <input type="text" class="cityInput controls"  id="pac-input" placeholder="City" id="city">
        <span class="close">Cancel</span>
        <div class="dialogCity">   
        </div>
      </div>
      <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12  autocomplete">
        <input type="text" class="doctorInput" placeholder="Doctor name / clinic name" id="doctor">
        <span class="close">Cancel</span>
        <div class="dialog">   
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 
        <button type="button" class="btn btn-signup" >GO</button>
      </div>
    </div>
 
    </form>
  </div>
  <iframe src="https://maps.google.com/maps?q=manhatan&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"
   allowfullscreen>
  </iframe>

</div>
</div>
<div class="no-padding col-sm-12 text-center doct_1">
<div id="map">test</div>
<input
      id="pac-input"
      class="controls"
      type="text"
      placeholder="Search Box"
    />
   
</div>

<!------>
  <div class="row no-padding cont_sec">
    <div class="col-sm-4 pad-rit-25">
      <div class="cont_box">
	  <div><img src="frontend/images/global_reach.png"></div>
	  <h3>Global reach</h3>        
      <p>Ut perum sequate stempori ut velique cor maiosti onsectati assinie nditem et omnient, tem quis autatem sintin re 
</p>
	 </div>
     
    </div>
    <div class="col-sm-4 pad-rit-25">
      <div class="cont_box">
	   <div><img src="frontend/images/message.png"></div>
	  <h3>Multi language</h3>        
      <p>Ut perum sequate stempori ut velique
cor maiosti onsectati assinie nditem
et omnient, tem quis autatem sintin re 
</p>
	 </div>
    </div>
    <div class="col-sm-4 pad-rit-25">
     <div class="cont_box">
	  <div><img src="frontend/images/stars_new.png" class="star_pad"></div>
	  <h3>Curated doctors
</h3>        
      <p>Ut perum sequate stempori ut velique
cor maiosti onsectati assinie nditem
et omnient, tem quis autatem sintin re 
</p>
	 </div>
    </div>
  </div>



  <div class="fullcont_sec">
   <div class="bg_grey">
   <div class="row">
    <div class="col-sm-8">
	<h3>Why use Doctored?</h3>
	<p>
	Ut perum sequate stempori ut velique cor maiosti onsectati assinie nditem et omnient, tem quis autatem
sintin re veruptam, consedCiis eostrum que et hilignatior apiditatur, officatquam fugia qui con eium harciam
incideni aut repe pra voluptam, quundaerata invel ipsam aut poratiatiur mo bea doluptaturem eum dolupta
imendaeseque siti ut atquo omnima volorecus alita ex ex eum eos eario dolupici volor sequostrum essitat 

	</p>
	</div>
	 <div class="col-sm-4 my-auto">
	 <div class="h-35"></div>
                            <button type="button" class="btn btn-signup w-75 h-25">Sign up</button>
                            <div class="h-35"></div>
	 </div>
   </div>
@endsection
