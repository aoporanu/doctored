@extends('Frontend::layouts.frontend')
@section('content')

<section class="breadcrumbs">
    <div class="container">

        <div class="row">
            <div class="col-lg-3 col-md-3 col-12 mt-2">
                <ol>
                    <li><a href="/doctor-dashboard">Home</a></li>
                    <li>Consultation</li>
                </ol>
            </div>

            <div class="col-lg-9 col-md-9 col-12">
                <div class="row justify-content-end">
                    <div class="col-lg-6 col-md-6 col-12">

                    </div>
                </div>
            </div>
        </div>

    </div>
</section><!-- End Breadcrumbs Section -->
<main id="main">
    <section class="inner-page">
        <div class="container">
            <div class="row">
                <div class="col-12 mx-auto">
                    <!-- Profile widget -->
                    <div class="bg-white shadow rounded overflow-hidden">
                        <div class="p-3 cover pos-rel">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                    <div class="media align-items-end profile-head">
                                        <div class="profile mr-3"><img src="assets/img/patient-pic1.jpg" alt="..." width="130" class="rounded mb-2 img-thumbnail"></div>
                                        <div class="media-body text-white">
                                            <h4 class="mt-0 mb-2 txt-white">Mr. Rajasekhar</h4>
                                            <p class="small mb-2">Id: #DOC0000001</p>
                                            <p class="small mb-2">Booking Date: 18/12/2020 | Slot Booked On: 11:00AM & 15:00PM</p>
                                            <p class="small mb-2">Appointment Date: 15/12/2020</p>
                                            <p class="small mb-2">Payment Status: Confirmed</p> 
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12 text-right">
                                    <div class="row">
                                        <div class="col-12 mt-1">
                                            <p class="badge badge-primary text-wrap"><i class="fa fa-phone" aria-hidden="true"></i> Telephone</p>
                                            <p class="badge badge-primary text-wrap"><i class="fa fa-user-md" aria-hidden="true"></i> Visit Practise</p>
                                            <p class="badge badge-primary text-wrap"><i class="fa fa-comments" aria-hidden="true"></i> Chat</p>
                                            <p class="badge badge-primary text-wrap"><i class="fa fa-video-camera" aria-hidden="true"></i> Video Call</p>
                                        </div>
                                        <div class="col-12">
                                            <p class="badge badge-primary text-wrap">English</p>
                                            <p class="badge badge-primary text-wrap">Hindi</p>
                                            <p class="badge badge-primary text-wrap">Telugu</p>
                                        </div>
                                        <div class="col-12 mb-0 mt-2"><a href="#" class="btn btn-primary ml-0">Enter OTP</a></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row ml-0 mr-0">
                            <div class="container">
                                <div class="accordion" id="accordionExample">
                                    <div class="card">
                                        <div class="card-head" id="headingOne">
                                            <h2 class="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                Consultation
                                            </h2>
                                        </div>

                                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <div class="row ml-0 mr-0">
                                                    <div class="col-lg-6 col-md-6 col-12 bg-grey">
                                                        <h4 class="txt-green">Symptoms: Chest Pain</h4>
                                                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                                                        <p class="consultation-choosed w-50 text-center"><i class="fa fa-video-camera" aria-hidden="true"></i>
                                                            <a href="#" class="btn btn-primary ml-0">Start Consultation</a>
                                                        </p>
                                                        <h5 class="txt-green">Change Consultation Type</h5>
                                                        <div class="row ml-0 mr-0">

                                                            <div class="change-consultation"><a href="#" class="btn btn-primary"><i class="fa fa-mobile" aria-hidden="true"></i> <span>Call</span></a></div>


                                                            <div class="change-consultation"><a href="#" class="btn btn-primary"><i class="fa fa-handshake-o" aria-hidden="true"></i> <span>In-Person</span></a></div>


                                                            <div class="change-consultation"><a href="#" class="btn btn-primary"><i class="fa fa-comments-o" aria-hidden="true"></i> <span>Chat</span></a></div>

                                                        </div>
                                                    </div>
                                                    <div class="col-lg-6 col-md-6 col-12">
                                                        <div class="row ml-0 mr-0 mb-3 d-flex justify-content-end">
                                                            <h6 class="mb-0 d-inline txt-green">Severity<span class="asterik">*</span></h6>
                                                            <div class="custom-control custom-radio custom-control-inline ml-2">
                                                                <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input" checked="">
                                                                <label class="custom-control-label" for="customRadioInline1">High</label>
                                                            </div>
                                                            <div class="custom-control custom-radio custom-control-inline">
                                                                <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input">
                                                                <label class="custom-control-label" for="customRadioInline2">Medium</label>
                                                            </div>
                                                            <div class="custom-control custom-radio custom-control-inline">
                                                                <input type="radio" id="customRadioInline3" name="customRadioInline1" class="custom-control-input">
                                                                <label class="custom-control-label" for="customRadioInline3">Low</label>
                                                            </div>
                                                        </div>
                                                        <div class="card mb-0 no-border">
                                                            <div class="card-header">

                                                                <!-- START TABS DIV -->
                                                                <div class="tabbable-responsive">
                                                                    <div class="tabbable">
                                                                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                                            <li class="nav-item">
                                                                                <a class="nav-link active" id="first-tab" data-toggle="tab" href="#first" role="tab" aria-controls="first" aria-selected="true">Doctor Notes</a>
                                                                            </li>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link" id="second-tab" data-toggle="tab" href="#second" role="tab" aria-controls="second" aria-selected="false">Prescription</a>
                                                                            </li>
                                                                            <li class="nav-item">
                                                                                <a class="nav-link" id="third-tab" data-toggle="tab" href="#third" role="tab" aria-controls="third" aria-selected="false">Reports</a>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="card-body p-2 card-border">                                    
                                                                <div class="tab-content">
                                                                    <div class="tab-pane fade show active" id="first" role="tabpanel" aria-labelledby="first-tab">
                                                                        <div class="row mb-3 ml-0 mr-0  ">
                                                                            <div class="col-12 text-right"><a href="#"><i class="fa fa-plus" aria-hidden="true"></i> Add</a></div>
                                                                        </div>
                                                                        <p class="card-text fixed-height"> 
                                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                        </p>
                                                                        <div class="row ml-0 mr-0 mt-3 d-flex justify-content-end">
                                                                            <a href="#" class="btn btn-primary ml-0 mr-3">Save</a> <a href="#" class="btn btn-primary ml-0 txt-grey">Cancel</a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tab-pane fade" id="second" role="tabpanel" aria-labelledby="second-tab">
                                                                        <div class="col-12 text-right mb-3 pr-0"><a href="#"><i class="fa fa-plus" aria-hidden="true"></i> Add</a></div>
                                                                        <p class="card-text fixed-height"> 
                                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                        </p>
                                                                        <div class="row ml-0 mr-0 mt-3 d-flex justify-content-end">
                                                                            <a href="#" class="btn btn-primary ml-0 mr-3">Save</a> <a href="#" class="btn btn-primary ml-0">Cancel</a>
                                                                        </div>
                                                                    </div>
                                                                    <div class="tab-pane fade" id="third" role="tabpanel" aria-labelledby="third-tab">
                                                                        <div class="col-12 text-right mb-3 pr-0"><a href="#"><i class="fa fa-plus" aria-hidden="true"></i> Add</a></div>
                                                                        <p class="card-text fixed-height"> 
                                                                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                                                                        </p>
                                                                        <div class="row ml-0 mr-0 mt-3 d-flex justify-content-end">
                                                                            <a href="#" class="btn btn-primary ml-0 mr-3">Save</a> <a href="#" class="btn btn-primary ml-0">Cancel</a>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                                <!-- END TABS DIV -->

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card">
                                        <div class="card-head" id="headingTwo">
                                            <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                Medical History
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse p-2 prev-history-container" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                            <div class="card">
                                                <div class="card-header">
                                                    <div class="row p-2">
                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                                                            <i class="fa fa-calendar-check-o txt-green" aria-hidden="true"></i> 10/12/2020 | <i class="fa fa-clock-o txt-green" aria-hidden="true"></i> 10:00 AM
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-6 col-6 text-right severity-block">Cardiologist | <i class="fa fa-circle red" aria-hidden="true"></i> <span>High</span></div>
                                                    </div>
                                                </div>
                                                <div class="card-body p-2">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <h5 class="mt-0 mb-1 txt-green">Symptoms: Chest Pain</h5>
                                                            <div class="media align-items-end profile-head">
                                                                <div class="profile mr-3"><img src="assets/img/doctor-pic.jpg" alt="..." width="90" class="rounded mb-2 img-thumbnail"></div>
                                                                <div class="media-body mb-4">
                                                                    <p class="small mb-1">Dr. Pradeep Reddy</p>
                                                                    <p class="small mb-1">Expert In: Cardiology</p>
                                                                    <p class="small mb-1">Apollo Hospitals | Begumpet</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <div class="prev-history-reports">
                                                                <ul class="nav nav-tabs" id="myTab">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#tabOne">Doctor Notes</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabTwo">Prescriptions</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabThree">Reports</a>
                                                                    </li>
                                                                </ul>
                                                                <div class="tab-content" id="myTabContent">
                                                                    <div class="tab-pane fade active show p-2" id="tabOne">Doctor Notes</div>
                                                                    <div class="tab-pane fade p-2" id="tabTwo">Prescriptions</div>
                                                                    <div class="tab-pane fade p-2" id="tabThree">Reports</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card">
                                                <div class="card-header">
                                                    <div class="row p-2">
                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                                                            <i class="fa fa-calendar-check-o txt-green" aria-hidden="true"></i> 10/12/2020 | <i class="fa fa-clock-o txt-green" aria-hidden="true"></i> 10:00 AM
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-6 col-6 text-right severity-block">Cardiologist | <i class="fa fa-circle orange" aria-hidden="true"></i> <span>Medium</span></div>
                                                    </div>
                                                </div>
                                                <div class="card-body p-2">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <h5 class="mt-0 mb-1 txt-green">Symptoms: Chest Pain</h5>
                                                            <div class="media align-items-end profile-head">
                                                                <div class="profile mr-3"><img src="assets/img/doctor-pic.jpg" alt="..." width="90" class="rounded mb-2 img-thumbnail"></div>
                                                                <div class="media-body mb-4">
                                                                    <p class="small mb-1">Dr. Pradeep Reddy</p>
                                                                    <p class="small mb-1">Expert In: Cardiology</p>
                                                                    <p class="small mb-1">Apollo Hospitals | Begumpet</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <div class="prev-history-reports">
                                                                <ul class="nav nav-tabs" id="myTab">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#tabFour">Doctor Notes</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabFive">Prescriptions</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabSix">Reports</a>
                                                                    </li>
                                                                </ul>
                                                                <div class="tab-content" id="myTabContent">
                                                                    <div class="tab-pane fade active show p-2" id="tabFour">Doctor Notes</div>
                                                                    <div class="tab-pane fade p-2" id="tabFive">Prescriptions</div>
                                                                    <div class="tab-pane fade p-2" id="tabSix">Reports</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="card">
                                                <div class="card-header">
                                                    <div class="row p-2">
                                                        <div class="col-lg-4 col-md-4 col-sm-6 col-6">
                                                            <i class="fa fa-calendar-check-o txt-green" aria-hidden="true"></i> 10/12/2020 | <i class="fa fa-clock-o txt-green" aria-hidden="true"></i> 10:00 AM
                                                        </div>
                                                        <div class="col-lg-8 col-md-8 col-sm-6 col-6 text-right severity-block">Cardiologist | <i class="fa fa-circle green" aria-hidden="true"></i> <span>Low</span></div>
                                                    </div>
                                                </div>
                                                <div class="card-body p-2">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <h5 class="mt-0 mb-1 txt-green">Symptoms: Chest Pain</h5>
                                                            <div class="media align-items-end profile-head">
                                                                <div class="profile mr-3"><img src="assets/img/doctor-pic.jpg" alt="..." width="90" class="rounded mb-2 img-thumbnail"></div>
                                                                <div class="media-body mb-4">
                                                                    <p class="small mb-1">Dr. Pradeep Reddy</p>
                                                                    <p class="small mb-1">Expert In: Cardiology</p>
                                                                    <p class="small mb-1">Apollo Hospitals | Begumpet</p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-12">
                                                            <div class="prev-history-reports">
                                                                <ul class="nav nav-tabs" id="myTab">
                                                                    <li class="nav-item">
                                                                        <a class="nav-link active" data-toggle="tab" href="#tabSeven">Doctor Notes</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabEight">Prescriptions</a>
                                                                    </li>
                                                                    <li class="nav-item">
                                                                        <a class="nav-link" data-toggle="tab" href="#tabNine">Reports</a>
                                                                    </li>
                                                                </ul>
                                                                <div class="tab-content" id="myTabContent">
                                                                    <div class="tab-pane fade active show p-2" id="tabSeven">Doctor Notes</div>
                                                                    <div class="tab-pane fade p-2" id="tabEight">Prescriptions</div>
                                                                    <div class="tab-pane fade p-2" id="tabNine">Reports</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>
@endsection
