<?php

$webMiddlewares = $middlewares = [
    \App\Http\Middleware\EncryptCookies::class,
    \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
    \Illuminate\Session\Middleware\StartSession::class,
    \Illuminate\View\Middleware\ShareErrorsFromSession::class,
    \Illuminate\Routing\Middleware\SubstituteBindings::class,
];
Route::any('/doctor/manage-prescription', 'App\Modules\Frontend\Controllers\IndexController@managePrescription');
Route::any('/doctor/manage-reports', 'App\Modules\Frontend\Controllers\IndexController@manageReports');
Route::any('/doctor/consultation', 'App\Modules\Frontend\Controllers\IndexController@doctorConsultation');
Route::post('/doctor/update_doctor_profile', 'App\Modules\Frontend\Controllers\IndexController@updateDoctorProfile');
Route::post('/doctor/update_doctor_meta', 'App\Modules\Frontend\Controllers\IndexController@updateDoctorMetaData');
Route::group(['middleware' => $middlewares], function () {

    Route::group(['namespace' => 'App\Http\Controllers\Auth'], function() {
        //Route::get('member-password-reset','ForgotPasswordController@showLinkRequestForm')->name('member.password.request');
        Route::post('member-password-email', 'ForgotPasswordController@sendResetLinkEmail')->name('member.password.email');
        Route::get('member-password/reset/{token}/{type?}', 'ResetPasswordController@showResetForm', function($id) {
            
        })->name('member.password.reset')->defaults('type', 0);
        Route::post('member-password/reset', 'ResetPasswordController@reset')->name('member.password.update');

        //Route::get('doctor-password-reset','DoctorForgotPasswordController@showLinkRequestForm',)->name('doctor.password.request');
        Route::post('doctor-password-email', 'DoctorForgotPasswordController@sendResetLinkEmail')->name('doctor.password.email');
        Route::get('doctor-password/reset/{token}/{type?}', 'DoctorResetPasswordController@showResetForm')->name('doctor.password.reset')->defaults('type', 1);
        Route::post('doctor-password/reset', 'DoctorResetPasswordController@reset')->name('doctor.password.update');
    });


    Route::group(['namespace' => 'App\Modules\Frontend\Controllers'], function () {
        Route::any('/', 'IndexController@home');
        Route::any('/settimezone/{id}', 'IndexController@settimezone');

        Route::view('/call', 'Frontend::call');
        Route::post('/callinit', 'VoiceController@initiateCall')->name('initiate_call');
        Route::post('/callinitn', 'VoiceController@newCall')->name('initiate_ncall');

        Route::any('/search', 'SearchController@index');
        Route::any('/getsuggestions', 'IndexController@getHospitalDoctorsList');
        Route::any('/group/{id}', 'IndexController@groupProfile');
        Route::any('/doctor/{id}', 'IndexController@doctorProfile');
        Route::any('/hospital/{id}', 'IndexController@hospitalProfile');
        
        
        Route::any('/doctor/editprofile/{id}', 'IndexController@editDoctorProfile');
        
        Route::any('/register', 'RegisterController@register');
        Route::any('/register_doctor', 'RegisterController@register_doctor');


        Route::any('/forgot-password', 'IndexController@forgot');
        Route::any('/contact-us', 'IndexController@contactus');
        Route::any('/homecontactsave', 'IndexController@homecontactsave');


        Route::any('/doctor-dashboard', 'DoctorDashboardController@doctorDashboard');

        Route::any('/clinic_info', 'DoctorDashboardController@clinicInfo');
        Route::any('/clinicsave', 'DoctorDashboardController@clinicSave');

        Route::any('/patient-dashboard', 'PatientDashboardController@patientDashboard');

        Route::any('/configure-slot', 'SlotConfigurationController@index'); //OLD 
        Route::any('/slotConfiguration', 'SlotConfigurationController@slotConfigure');

        Route::any('/slotsdetails', 'SlotConfigurationController@slotsdetails');
        Route::any('/updateSlotConfiguration', 'SlotConfigurationController@updateSlotConfiguration');

        Route::any('/manage-slots', 'SlotConfigurationController@manage');
        Route::any('/fetchdurations', 'SlotConfigurationController@fetchdurations');
        Route::any('/saveSlotConfiguration', 'SlotConfigurationController@saveSlotConfiguration');
        Route::any('/fetchSlotConfiguration', 'SlotConfigurationController@fetchSlotConfiguration');
        Route::any('/generateAppointments', 'SlotConfigurationController@generateAppointments');
        Route::any('/deletedetails', 'SlotConfigurationController@deletedetails');

        Route::any('/managebookings', 'BookingAppointmentController@managebookings');

        Route::any('/book-appointment', 'BookingAppointmentController@index');
        Route::any('/fsdbh', 'BookingAppointmentController@fetchSlotDetailsByHospital');
        Route::any('/fctype', 'BookingAppointmentController@fetchConsulationsByDate');
        Route::any('/fstbd', 'BookingAppointmentController@fetchSlotTimesByDate');

        


        Route::post('/getappointmenttimes', 'BookingAppointmentController@getAppointmentTimes');
        Route::post('/initiateBooking', 'BookingAppointmentController@initiateBooking');
        Route::any('/fetchSlotsByHospital ', 'IndexController@fetchSlotsByHospital');
        Route::any('/fetchSlotsByDoctor ', 'IndexController@fetchSlotsByDoctor');

        // Route::post('contact-us','IndexController@saveContact');
        Route::any('/getCountries', 'CommonController@getCountries');
        Route::any('/getStates', 'CommonController@getStates');
        Route::any('/getStates/{id}', 'CommonController@getStates');


        Route::any('/getCities', 'CommonController@getCities');
        Route::any('/getCities/{id}', 'CommonController@getCities');
        Route::any('/getTimezones', 'CommonController@getTimezones');


        Route::any('/testc', 'CommonController@testc');

        //Route::pattern('tags', '[0-9a-z]+');
        Route::get('/{slug}', array('as' => 'page.show', 'uses' => 'IndexController@show'));
    });
});

