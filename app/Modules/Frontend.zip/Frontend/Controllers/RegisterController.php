<?php

namespace App\Modules\Frontend\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Redirect;
use View;
use Session;
use Mail;
use Illuminate\Support\Facades\DB;
use App\Modules\Frontend\Models\Contacts as Contact;
use App\Modules\Admin\Models\Patients as Patient;
use App\Modules\Admin\Models\Doctors as Doctor;
use App\Modules\Admin\Models\Groups as Group;
use App\Modules\Admin\Models\GroupRoleMapping as GroupMap;
use App\Modules\Admin\Models\GroupUserMapping as GroupUserMap;
use App\Modules\Admin\Models\UserRoleMapping as UserRoleMap;

use App\Modules\Admin\Models\ProcessLogs as ProcessLog;
use Illuminate\Support\Facades\Validator;

use App\Modules\Admin\Models\Users as User;
use Illuminate\Support\Facades\Hash;

class RegisterController extends Controller
{
    public function home()
    {
        return view('Frontend::home');
    }
    public function register(Request $request)
    {
        if ($request->isMethod('post')) {
            session()->put('tab_name', 'mem_link');
            // dd($request->all()); //
            $this->validate(
                $request,
                [
                    'firstname' => [
                        'required',
                        'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'
                    ],
                    'lastname' => [
                        'required',
                        'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'
                    ],
                    'phonenumber' => 'required|numeric|digits_between:10,12', //'phone:country|unique:patients'
                    'phone' => 'unique:patients',
                    'email' => 'required|email|unique:patients',
                    'password' => [
                        'required',
                        'min:8',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/'
                    ],
                    'password_confirmation' => 'required|same:password'
                ],
                [
                    'firstname.required' => 'First Name is required',
                    'firstname.regex' =>
                        'First Name format is invalid , use characters only',
                    'lastname.regex' =>
                        'Last Name format is invalid , use characters only',
                    'phonenumber.required' => 'Phone Number  is required',
                    'phone.unique' => 'Number is already exist ',
                    'email.required' => 'Emai Address is required ',
                    'email.unique' =>
                        'Record already existing with same Email address',
                    'password.required' => 'Password is required',
                    'password.min' => 'Minimum 8 charcters required',
                    'password.regex' => 'Invalid Format',
                    'password_confirmation.required' =>
                        'Password Confirmation required',
                    'password_confirmation.same' =>
                        'Password Confirmation  should be same Account password'
                ]
            );

            $input = $request->all();
            $max = DB::table('patients')->max('id');
            if ($max == '') {
                $max = 1;
            } else {
                $max++;
            }
            $patient_code = 'PMEFR' . date('y') . (1000 + $max);
            $patientData = new Patient();
            $patientData->patientcode = $patient_code;
            $patientData->firstname = $request->firstname;
            $patientData->lastname = $request->lastname;
            $patientData->phone = $request->phone;
            $patientData->email = $request->email;
            $patientData->password = Hash::make($request->password);
            $patientData->visitor = $this->getUserIpAddr();
            DB::enableQueryLog();

		if($patientData->save()){
			   $process_log['patient_data'] = $patientData; 
		 
            \Mail::send(
                'Frontend::activation_email',
                array(
                    'firstname' => $request->firstname,
                    'email' => $request->email,
                    'password' => $request->password,
                    'patient_code' => $patient_code
                ),
                function ($message) use ($request) {
                    $message->subject('Registration Successful.');
                    $message->from(getenv('MAIL_FROM_ADDRESS'));
                    $message->to($request->email);
                }
            );

            \Mail::send(
                'Frontend::activation_admin_email',
                array(
                    'firstname' => $request->firstname,
                    'lastname' => $request->lastname,
                    'email' => $request->email,
                    'patient_code' => $patient_code
                ),
                function ($message) use ($request) {
                    $message->subject('Member registered');
                    $message->from(getenv('MAIL_FROM_ADDRESS'));
                    $message->to(getenv('MAIL_FROM_ADDRESS')); //admin email
                }
            );
            // dd(DB::getQueryLog());
            session()->forget('tag_name');
			$failed_array['user_data'] = $patientData;
				 $this->logProcess(
                    0,
                    'register_patient',
                    'Notify',
                    json_encode($failed_array)
                );
            return back()->with(
                'success',
                'Thank you for registering with us!');
		}else{
			 
                $failed_array['user_data'] = $patientData;
				 $this->logProcess(
                    0,
                    'register_patient',
                    'Notify',
                    json_encode($failed_array)
                );
             return back()->with(
					'error',
                'Something went wrong!');
			
		}
        }
        /* $tab_name = isset($request->tab)?$request->tab:'mem_link';
        return view('Frontend::register')->with('tab_name',$tab_name);
		
		*/

        return view('Frontend::register');
    }
    public function register_doctor(Request $request)
    {
        if ($request->isMethod('post')) {
            session()->put('tab_name', 'doc_link');
            //dd($request->all()); //
            $input = $request->all();
            $validator = Validator::make(
                //$this->validate(
                $input,
                [
                    'firstname' => [
                        'required',
                        'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'
                    ],
                    'lastname' => [
                        'required',
                        'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'
                    ],
                    //  'phone' => 'unique:doctors',
                    'phonenumber' => 'required|numeric|digits_between:10,12', //'phone:country|unique:patients'
                    'phone' => 'unique:doctors',
                    'email' => 'required|email|unique:doctors',

                    'licence' => 'required|digits_between:7,7|unique:doctors',
                    'password' => [
                        'required',
                        'min:8',
                        'regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/'
                    ],
                    'password_confirmation' => 'required|same:password'
                ],
                [
                    'firstname.required' => 'First Name is required',
                    'firstname.regex' =>
                        'First Name format is invalid , use characters only',
                    'lastname.required' => 'Last Name is required',
                    'lastname.regex' =>
                        'Last Name format is invalid , use characters only',
                    'phonenumber.required' => 'Phone Number  is required',
                    'phone.unique' => 'Number is already exist ',
                    'email.required' => 'Emai Address is required ',
                    'email.unique' =>
                        'Record already existing with same Email address',
                    'licence.required' => 'Licence/GMC is required',
                    'licence.digits_between' => 'Licence should be 7 numbers',

                    'password.required' => 'Password is required',
                    'password.min' => 'Minimum 8 charcters required',
                    'password.regex' => 'Invalid Format',
                    'password_confirmation.required' =>
                        'Password Confirmation required',
                    'password_confirmation.same' =>
                        'Password Confirmation  should be same Account password'
                ]
            );
            if ($validator->fails()) {
                return redirect('/register')
                    ->withErrors($validator)
                    ->withInput();
            }
            //echo 'dddd';die;

            $max = DB::table('doctors')->max('id');
            if ($max == '') {
                $max = 1;
            } else {
                $max++;
            }
            $doctor_code = 'DMEFR' . date('y') . (1000 + $max);
            $doctorData = new Doctor();
            $doctorData->doctorcode = $doctor_code;
            $doctorData->firstname = $request->firstname;
            $doctorData->lastname = $request->lastname;
            $doctorData->phone = $request->phone;
            $doctorData->email = $request->email;
            $doctorData->licence = $request->licence;
            $doctorData->opt_clinic = $request->is_clinic;
            $doctorData->password = Hash::make($request->password);
            $doctorData->visitor = $this->getUserIpAddr();
            //Recommended : Add failed log for else case  as a array add all steps error to it
            $failed_array = array();
            $process_log = array();
            if ($doctorData->save()) {
                $process_log['doctor_data'] = $doctorData; //log

                //logic to send communication to Admin
                \Mail::send(
                    'Frontend::admin_doctor_verification',
                    array(
                        'doctorData' => $doctorData
                    ),
                    function ($message) use ($request) {
                        $message->subject('Doctor Verification Required');
                        $message->from(getenv('MAIL_FROM_ADDRESS'));
                        $message->to(getenv('MAIL_FROM_ADDRESS'));
                    }
                );

                //logic to send communication to Admin
                \Mail::send(
                    'Frontend::doctor_notification_one',
                    array(
                        'doctorName' =>
                            $doctorData->title . " " . $doctorData->firstname
                    ),
                    function ($message) use ($request) {
                        $message->subject('Account Created');
                        $message->from(getenv('MAIL_FROM_ADDRESS'));
                        $message->to($request->email);
                    }
                );
            } else {
                $failed_array['user_data'] = $doctorData;
            }

            /*---------------------------------------------*/
            //store logs --method name,fail/notify,data,date
            if (count($failed_array) > 0) {
                $this->logProcess(
                    0,
                    'register_doctor',
                    'Error',
                    json_encode($failed_array)
                ); //LogProcess($userid,$method,$type,$data)
            }

            if (count($process_log) > 0) {
                $this->logProcess(
                    0,
                    'register_doctor',
                    'Notify',
                    json_encode($process_log)
                ); //LogProcess($userid,$method,$type,$data)
            }
            /*---------------------------------------------*/

            //Mails
            $msg = 'Thank you for registering with us!';
            session()->forget('tag_name');
            return back()->with('success', $msg);
        }
    }

    public function getUserIpAddr()
    {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        } else {
            $ipaddress = 'UNKNOWN';
        }
        return $ipaddress;
    }
    public function logProcess($userid, $method, $type, $data)
    {
        $ProcessLogData = new ProcessLog();
        $ProcessLogData->user_id = $userid;
        $ProcessLogData->method = $method;

        $ProcessLogData->log_type = $type;
        $ProcessLogData->log = $data;
        $ProcessLogData->save();
    }
}
?>
