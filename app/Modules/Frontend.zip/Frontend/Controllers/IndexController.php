<?php

namespace App\Modules\Frontend\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Redirect;
use View;
use Session;
use Illuminate\Support\Facades\DB;
use App\Modules\Frontend\Models\Contacts as Contact;
use App\Modules\Admin\Models\Patients as Patient;
use App\Modules\Admin\Models\Hospitals;
use App\Modules\Admin\Models\Groups;
use App\Modules\Admin\Models\GroupHospitalMapping;
use App\Modules\Frontend\Models\Doctor;
use App\Modules\Frontend\Models\Slots as Slots;
use App\Modules\Admin\Models\Pages as Pages;
use App\Modules\Admin\Models\PageElements as PageElements;
use Log;
//use App\Frontend\Contact;
use Mail;
use Auth;

/*
  use App\Page;
  use App\Page_elements;

 */

class IndexController extends Controller {

    public function settimezone(Request $request, $id) {
        $timezone = DB::table('timezones')->select('timezone')->where('countrycode', $id)->get()->first();
        //print_r($timezone);
        date_default_timezone_set($timezone->timezone);
        //echo $id; exit;
    }

    public function home() {
        $homerequired = array('our-vision', 'frequently-asked-questions', 'contact', 'why-choose-doctored', 'store-records', 'reach-doctors', 'language-support', 'how-does-it-work', 'multi-speciality-clinics');
        $pagesdata = Pages::select('title', 'slug', 'description')->whereIn('slug', $homerequired)->get()->toArray();
        //echo "<pre>";		print_r($pagesdata);exit;
        $pagedata = array();
        foreach ($pagesdata as $pd_key => $pd_val) {
            $pagedata[$pd_val['slug']] = $pd_val;
        }
        $page_elements = PageElements::select('element_name', 'element_value')->where('page_id', 9)->get()->toArray();



        return view('Frontend::home')->with(compact('pagedata', 'page_elements'));
    }

    public function fetchSlotsByDoctor(Request $request) {
        $data = $request->all();
        $did = $data['id'];
        $slots = Slots::select('id', 'booking_date', 'booking_time_long', 'hospital_id', 'doctor_id', 'screen_id')->where('doctor_id', $did)->orderBy('booking_date', 'asc')
                ->get()
                ->toArray();
        $design = "<h2>Choose an appointment:</h2>";
        if (count($slots) > 0) {
            $restructure = array();

            //print_r($slots);
            foreach ($slots as $sl_key => $sl_val) {
                $dates[] = $sl_val['booking_date'];
                //$restructure[$sl_val['doctor_id']][$sl_val['screen_id']][$sl_val['booking_date']][] = $sl_val['booking_time_long']; //Perfect need to use$restructure[$sl_val['doctor_id']][$sl_val['screen_id']][$sl_val['booking_date']][] = $sl_val['booking_time_long'];
                $restructure[$sl_val['doctor_id']][$sl_val['booking_date']][$sl_val['hospital_id']][] = $sl_val['booking_time_long'];
            }
            $dates = array_unique($dates);
            $design .= "<p>";
            foreach ($dates as $d_k => $d_v) {
                $booking_date = str_replace('-', '', $d_v);

                $design .= '<a data-toggle="collapse" data-target="#date_' . $booking_date . '" aria-expanded="false" aria-controls="date_' . $booking_date . '">
		  <span class="badge badge-pill badge-primary sort_bage norm_bad2">' . $d_v . '</span></a>';
            }
            $times = array();
            foreach ($restructure as $rk => $rv) {

                foreach ($rv as $rrk => $rrv) {
                    $booking_dates = str_replace('-', '', $rrk);
                    $design .= '<div id="date_' . $booking_dates . '" class="collapse multi-collapse">';
                    foreach ($rrv as $k => $v) {
                        foreach ($v as $finalkey => $finalval) {
                            $design .= "<a class='btn btn-sm' href='/book-appointment?doctor_id=" . $rk . "&hospital_id=" . $k . "'>" . $finalval . "</a>";
                        }
                    }
                    $design .= '</div>';
                }
                //$times = array_unique($times);
            }

            // $design .= '<a class="btn doc_stand_cta" href="/book-appointment?doctor_id="' . $hospital . '"&hospital_id="' . $hospital . '" role="button">Make an appointment</a>';
            $design .= "</p>";
        } else {
            $design .= " Currently No Slots available";
        }
        echo $design;
    }

    public function fetchSlotsByHospital(Request $request) {
        $data = $request->all();
        $hospital = $data['id'];
        $slots = Slots::select('id', 'booking_date', 'booking_time_long', 'hospital_id', 'doctor_id', 'screen_id')->where('hospital_id', $hospital)->orderBy('booking_date', 'asc')
                ->get()
                ->toArray();
        $design = "<h2>Choose an appointment:</h2>";
        if (count($slots) > 0) {
            $restructure = array();

            //print_r($slots);
            foreach ($slots as $sl_key => $sl_val) {
                $dates[] = $sl_val['booking_date'];
                //$restructure[$sl_val['doctor_id']][$sl_val['screen_id']][$sl_val['booking_date']][] = $sl_val['booking_time_long']; //Perfect need to use$restructure[$sl_val['doctor_id']][$sl_val['screen_id']][$sl_val['booking_date']][] = $sl_val['booking_time_long'];
                $restructure[$sl_val['doctor_id']][$sl_val['booking_date']][$sl_val['hospital_id']][] = $sl_val['booking_time_long'];
            }
            $dates = array_unique($dates);

            $design .= "<p>";
            foreach ($dates as $d_k => $d_v) {
                $booking_date = str_replace('-', '', $d_v);

                $design .= '<a data-toggle="collapse" data-target="#date_' . $booking_date . '" aria-expanded="false" aria-controls="date_' . $booking_date . '">
		  <span class="badge badge-pill badge-primary sort_bage norm_bad2">' . $d_v . '</span></a>';
            }
            $times = array();
            foreach ($restructure as $rk => $rv) {

                foreach ($rv as $rrk => $rrv) {
                    $booking_dates = str_replace('-', '', $rrk);
                    $design .= '<div id="date_' . $booking_dates . '" class="collapse multi-collapse">';
                    foreach ($rrv as $k => $v) {
                        foreach ($v as $finalkey => $finalval) {
                            $design .= "<a class='btn btn-sm' href='/book-appointment?doctor_id=" . $rk . "&hospital_id=" . $k . "'>" . $finalval . "</a>";
                        }
                    }
                    $design .= '</div>';
                }
                //$times = array_unique($times);
            }

            // $design .= '<a class="btn doc_stand_cta" href="/book-appointment?doctor_id="' . $hospital . '"&hospital_id="' . $hospital . '" role="button">Make an appointment</a>';
            $design .= "</p>";

            $design .= "";
        } else {
            $design .= " Currently No Slots available";
        }
        echo $design;

        //  return view('Frontend::slots/slotdetails')        ->with(compact('doctorInfo','screen_id','restructure','slots_length','hospital'));
    }

    public function search_old(Request $request) { //Added in SearchController
        try {
            $key = $request->input('key');
            $type = $request->input('type');
            $group_id = $request->input('group_id');
            if ($type == 'group' && $group_id != '') {
                $hoselect = ["h.hospital_id as id", "hospital_name as name", 'hospitalcode as code', 'phone', 'email', 'summary', 'logo as photo', DB::raw("'Hospital' as type")];
                $hospitals = DB::table('hospitals as h')->select($hoselect)->join('group_hospital_mapping as ghm', 'ghm.hospital_id', '=', 'h.hospital_id')
                        ->where('ghm.group_id', $group_id)
                        //->where('is_active',1)->where('is_verified',1)
                        ->get()
                        ->all();
                $result = $hospitals;
            } else {
                $docselect = ["id", DB::raw("CONCAT(title, ' ' ,firstname, ' ' ,lastname) as name"), 'doctorcode as code', 'phone', 'email', 'summary', 'photo', DB::raw("'Doctor' as type")];
                $doctors = Doctor::select($docselect)->where('firstname', 'ilike', '%' . $key . '%')->orWhere('lastname', 'ilike', '%' . $key . '%')
                        //->where('is_active',1)->where('is_verified',1)
                        ->get()
                        ->all();

                $doctors = json_decode(json_encode($doctors));
                $hoselect = ["hospital_id as id", "hospital_name as name", 'hospitalcode as code', 'phone', 'email', 'summary', 'logo as photo', DB::raw("'Hospital' as type")];
                $hospitals = Hospitals::select($hoselect)->where('hospital_name', 'ilike', '%' . $key . '%')
                        //->where('is_active',1)->where('is_verified',1)
                        ->get()
                        ->all();
                $hospitals = json_decode(json_encode($hospitals));
                $result = array_merge($hospitals, $doctors);
            }

            print_r($result);
            exit;
            //  return view('Frontend::search')->with('result', $result);
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function hospitalProfile(Request $request, $id) {
        try {
            $hospitals = DB::table('hospitals')
                    ->select('hospitals.hospital_id',
                            'hospitals.hospital_name',
                            'hospitals.hospitalcode',
                            'hospitals.hospital_business_name',
                            'hospitals.hospital_type',
                            'hospitals.logo as hlogo',
                            'hospitals.phone as hphone',
                            'hospitals.email as hemail',
                            'hospitals.address_line1 as haddress1',
                            'hospitals.address_line2 as haddress2',
                            'hospitals.address_city as hcity',
                            'hospitals.address_state as hstate',
                            'hospitals.address_country as hcountry',
                            'hospitals.location as hlocation',
                            'hospitals.address_place as hplace',
                            'hospitals.address_lat as haddress_lat',
                            'hospitals.address_long as haddress_long',
                            'hospitals.summary as hsummary',
                            'doctors.id',
                            'doctors.title',
                            'doctors.firstname',
                            'doctors.photo',
                            'doctors.lastname',
                            'doctors.doctorcode',
                            'doctors.phone as dphone',
                            'doctors.email as demail',
                            'doctors.summary as dsummary',
                            'doctors.address_line1 as dadd1',
                            'doctors.address_line2 as dadd2',
                            'doctors.address_city as daddress_city',
                            'doctors.address_state as daddress_state',
                            'doctors.address_country as daddress_country',
                            'doctors.address_postcode as daddress_postcode',
                            'doctors.address_place as daddress_place',
                            'doctors.address_lat as daddress_lat',
                            'doctors.address_long as daddress_long'
                    )
                    ->leftjoin('hospital_doctor_mapping', 'hospital_doctor_mapping.hospital_id', '=', 'hospitals.hospital_id')
                    ->leftjoin('doctors', 'doctors.id', '=', 'hospital_doctor_mapping.doctor_id')

                    //->join('follows', 'follows.user_id', '=', 'users.id')
                    ->where('hospitals.hospitalcode', '=', $id)
                    ->get();
            $hdata = array();
            foreach ($hospitals as $hkey => $hval) {
                $hdata['hospital_id'] = $hval->hospital_id;
                $hdata['hospital_name'] = $hval->hospital_name;
                $hdata['hospitalcode'] = $hval->hospitalcode;
                $hdata['hospital_business_name'] = $hval->hospital_business_name;
                $hdata['hospital_type'] = $hval->hospital_type;
                $hdata['hlogo'] = $hval->hlogo;
                $hdata['hphone'] = $hval->hphone;
                $hdata['hemail'] = $hval->hemail;
                $hdata['haddress1'] = $hval->haddress1;
                $hdata['hcity'] = $hval->hcity;
                $hdata['hstate'] = $hval->hstate;
                $hdata['hcountry'] = $hval->hcountry;
                $hdata['hlocation'] = $hval->hlocation;
                $hdata['hplace'] = $hval->hplace;
                $hdata['haddress_lat'] = $hval->haddress_lat;
                $hdata['haddress_long'] = $hval->haddress_long;
                $hdata['hsummary'] = $hval->hsummary;
                $hdata['doctors'][] = array(
                    'title' => $hval->title,
                    'firstname' => $hval->firstname,
                    'lastname' => $hval->lastname,
                    'dphone' => $hval->dphone,
                    'demail' => $hval->demail,
                    'dsummary' => $hval->dsummary,
                    'doctorcode' => $hval->doctorcode,
                    'dadd1' => $hval->dadd1,
                    'dadd2' => $hval->dadd2,
                    'daddress_city' => $hval->daddress_city,
                    'daddress_state' => $hval->daddress_state,
                    'daddress_country' => $hval->daddress_country,
                    'daddress_postcode' => $hval->daddress_postcode,
                    'daddress_place' => $hval->daddress_place,
                    'daddress_lat' => $hval->daddress_lat,
                    'daddress_long' => $hval->daddress_long,
                    'photo' => $hval->photo
                );
            }
            return view('Frontend::profile/hospital_profile')
                            ->with(compact('hdata'));
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function groupProfile(Request $request, $id) {
        try {

            $groups = DB::table('group')
                    ->select('group.gid', 'group.group_name', 'group.logo as glogo', 'group.group_description', 'group.group_business_name', 'group.address as gaddress',
                            'group.address_place as gplace', 'group.address_long as glong', 'group.address_lat as glat', 'group.phone as gphone', 'group.email as gemail'
                            , 'hospitals.*')
                    ->leftjoin('group_hospital_mapping', 'group_hospital_mapping.group_id', '=', 'group.gid')
                    ->leftjoin('hospitals', 'hospitals.hospital_id', '=', 'group_hospital_mapping.hospital_id')

                    //->join('follows', 'follows.user_id', '=', 'users.id')
                    ->where('group.gid', '=', $id)
                    ->get();
            $groupdata = array();
            $hospitals = array();
            foreach ($groups as $gk => $gv) {
                $groupdata['gid'] = $gv->gid;
                $groupdata['group_name'] = $gv->group_name;
                $groupdata['glogo'] = $gv->glogo;
                $groupdata['group_description'] = $gv->group_description;
                $groupdata['group_business_name'] = $gv->group_business_name;
                $groupdata['gaddress'] = $gv->gaddress;
                $groupdata['gplace'] = $gv->gplace;
                $groupdata['glong'] = $gv->glong;
                $groupdata['glat'] = $gv->glat;
                $groupdata['gphone'] = $gv->gphone;
                $groupdata['gemail'] = $gv->gemail;
                $groupdata['hospitals'][] = array('hospital_id' => $gv->hospital_id,
                    'hospital_name' => $gv->hospital_name,
                    'hospitalcode' => $gv->hospitalcode,
                    'hospital_business_name' => $gv->hospital_business_name,
                    'hospital_type' => $gv->hospital_type,
                    'logo' => $gv->logo,
                    'banner' => $gv->banner,
                    'phone' => $gv->phone,
                    'email' => $gv->email,
                    'fax' => $gv->fax,
                    'licence' => $gv->licence,
                    'address_line1' => $gv->address_line1,
                    'address_line2' => $gv->address_line2,
                    'address_city' => $gv->address_city,
                    'address_country' => $gv->address_country,
                    'location' => $gv->location,
                    'address_place' => $gv->address_place,
                    'address_lat' => $gv->address_lat,
                    'address_long' => $gv->address_long,
                    'summary' => $gv->summary,
                    'address_state' => $gv->address_state,
                    'address_postcode' => $gv->address_postcode,
                );
            }

            return view('Frontend::profile/group_profile')
                            ->with(compact('groupdata'));
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function doctorProfile(Request $request, $id) {

        try {
            $doctorInfo = json_decode(json_encode(Auth::guard('doctor')->user()),1);
            $docselect = ['doctors.id', 'doctors.doctorcode', 'doctors.phone', 'doctors.email', 'licence', 'gender', 'dob', 'photo', 'summary', 'timezone',
                'address_line1', 'address_line2', 'address_line3', 'address_postcode', 'title', 'licence_file', 
                'address_city', 'address_state', 'address_country',
                'address_place', 'address_lat', 'address_long', 'firstname', 'lastname',
                DB::raw("CONCAT(doctors.firstname, ' ' ,doctors.lastname) as dname")
                , 'cities.name as cityname', 'states.name as statename', 'countries.name as countryname'
            ];
            $doctordata = DB::table('doctors')->select($docselect)->where('doctorcode', $id)
                            ->leftjoin('cities', DB::raw('CAST(cities.id AS varchar)'), 'address_city')
                            ->leftjoin('states', DB::raw('CAST(states.id AS varchar)'), 'address_state')
                            ->leftjoin('countries', 'countries.sortname', 'address_country')
                            ->get()->toArray();
            if($doctordata){                
                if(!empty($doctordata) && isset($doctordata[0]->phone) && $doctordata[0]->phone != ''){
                    $phoneDetails = explode('-', $doctordata[0]->phone);
                    $doctordata[0]->phoneCode = isset($phoneDetails[0]) ? $phoneDetails[0] : '';
                    $doctordata[0]->phoneNumber = isset($phoneDetails[1]) ? $phoneDetails[1] : '';
                }
            }
            //consultations  
            $consultations = DB::table('consultation_mapping')
                            ->where('doctors.doctorcode', $id)
                            ->select('consultation_types.ctype_name', 'consultation_types.ctype_icon', 'consultation_types.ctype_id')
                            ->leftjoin('consultation_types', 'consultation_types.ctype_id', 'consultation_mapping.consultation_id')
                            ->leftjoin('doctors', 'consultation_mapping.mapping_type_id', 'doctors.id')
                            ->get()->toArray();

            $allctype = DB::table('consultation_types')->select('ctype_id', 'ctype_name', 'ctype_icon')->get()->toArray();
            $allctypes = array();
            //print_r($allctype);
            foreach ($allctype as $akey => $aval) {

                $allctypes[$aval->ctype_id] = array($aval->ctype_name, $aval->ctype_icon);
            }
            $allctypes = json_encode($allctypes);

            $languageData = \App\Modules\Admin\Models\Languages::all()->where('is_delete', 0);
            //languages 
            $languages = DB::table('lang_mapping')
//                            ->select('languages.*')
                            ->where('lang_mapping.module_mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'lang_mapping.module_mapping_type_id', 'doctors.id')
                            ->leftjoin('languages', 'languages.id', 'lang_mapping.lang_mapping_id')
                            ->get()->toArray();
            $languageList = [];
            if ($languages) {
                foreach ($languages as $langInfo) {
                    $languageList[] = trim($langInfo->lang_mapping_id);
                }
            }

            //specialization 
            $specialization = DB::table('specialization_mapping')
                            ->select('specialization_types.specialization_shortcode')
                            ->where('specialization_mapping.mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'specialization_mapping.mapping_type_id', 'doctors.id')
                            ->leftjoin('specialization_types', 'specialization_types.id', 'specialization_mapping.specialization_id')
                            ->get()->toArray();

            //meta data 
            $metadata = DB::table('metatype_data')
                            ->select('metatype_data.mapping_type_data_value', 'doctor_metatypes.dmetaname')
                            ->where('metatype_data.mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'metatype_data.mapping_type_id', 'doctors.id')
                            ->leftjoin('doctor_metatypes', 'doctor_metatypes.dmeta_id', 'metatype_data.mapping_type_data_id')
                            ->get()->toArray();

//DB::enableQueryLog();
            $slotsquery = DB::table('slots')
                    ->select('slots.hospital_id', 'booking_start_time', 'slots.id as slotid', 'screen_id', 'hospital_name', 'shift', 'booking_date', 'booking_time_long', 'available_types')
                    ->where('slots.is_delete', '0')
                    ->where('slots.is_active', '1')
                    ->where('booking_date', '>=', date('d-m-Y'))
//                    ->where(DB::raw('CAST(booking_date AS date)'), '>=', date('d-m-Y'))
//                    ->WhereRaw('booking_date::date >= '."'".date('d-m-Y')."'")
                    ->where('doctors.doctorcode', $id)
                    // ->groupBy('slot_configurations.hospital_id')
                    ->leftjoin('doctors', 'slots.doctor_id', 'doctors.id')
                    ->leftjoin('hospitals', 'slots.hospital_id', 'hospitals.hospital_id');

            if (isset($_REQUEST['h']) && $_REQUEST['h'] != '') {
                $slotsquery->where('slots.hospital_id', $_REQUEST['h']);
            }
            
            $doctorMetaTypes = \App\Modules\Admin\Models\DoctorMetaTypes::all()->where('is_active', '1')->where('is_delete', 0);
            $docMetaData = \App\Modules\Admin\Models\MetatypeData::leftjoin('doctors', 'doctors.id', '=', 'metatype_data.mapping_type_id')
                    ->where('metatype_data.mapping_type', 'Doctor')
                    ->where('doctors.doctorcode', $id)->get()->all();
            $docMetaList = [];
            if ($docMetaData) {
                foreach ($docMetaData as $docMetaInfo) {
                    $docMetaList[$docMetaInfo->mapping_type_data_id] = $docMetaInfo->mapping_type_data_value;
                }
            }

            $slots = $slotsquery->get()->toArray();
//            echo __METHOD__;
//            echo "<pre>";print_r($slots);
//            exit;
//            dd(DB::getQueryLog());
            return view('Frontend::profile/doctor_profile')
                            ->with(compact('doctordata', 'consultations', 'languages', 'languageData', 'languageList', 'specialization', 'metadata', 'slots', 'allctypes'))
                    ->with(['doctorMetaTypes' => $doctorMetaTypes, 'docMetaList' => $docMetaList, 'doctorInfo' => $doctorInfo]);
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }
    
    public function editDoctorProfile(Request $request, $id) {

        try {
            $doctorInfo = json_decode(json_encode(Auth::guard('doctor')->user()),1);
            $docselect = ['doctors.id', 'doctors.doctorcode', 'doctors.phone', 'doctors.email', 'licence', 'gender', 'dob', 'photo', 'summary', 'timezone',
                'address_line1', 'address_line2', 'address_line3', 'address_postcode', 'title', 'licence_file', 
                'address_city', 'address_state', 'address_country',
                'address_place', 'address_lat', 'address_long', 'firstname', 'lastname',
                DB::raw("CONCAT(doctors.firstname, ' ' ,doctors.lastname) as dname")
                , 'cities.name as cityname', 'states.name as statename', 'countries.name as countryname'
            ];
            $doctordata = DB::table('doctors')->select($docselect)->where('doctorcode', $id)
                            ->leftjoin('cities', DB::raw('CAST(cities.id AS varchar)'), 'address_city')
                            ->leftjoin('states', DB::raw('CAST(states.id AS varchar)'), 'address_state')
                            ->leftjoin('countries', 'countries.sortname', 'address_country')
                            ->get()->toArray();
            if($doctordata){                
                if(!empty($doctordata) && isset($doctordata[0]->phone) && $doctordata[0]->phone != ''){
                    $phoneDetails = explode('-', $doctordata[0]->phone);
                    $doctordata[0]->phoneCode = isset($phoneDetails[0]) ? $phoneDetails[0] : '';
                    $doctordata[0]->phoneNumber = isset($phoneDetails[1]) ? $phoneDetails[1] : '';
                }
            }
            //consultations  
            $consultations = DB::table('consultation_mapping')
                            ->where('doctors.doctorcode', $id)
                            ->select('consultation_types.ctype_name', 'consultation_types.ctype_icon', 'consultation_types.ctype_id')
                            ->leftjoin('consultation_types', 'consultation_types.ctype_id', 'consultation_mapping.consultation_id')
                            ->leftjoin('doctors', 'consultation_mapping.mapping_type_id', 'doctors.id')
                            ->get()->toArray();

            $allctype = DB::table('consultation_types')->select('ctype_id', 'ctype_name', 'ctype_icon')->get()->toArray();
            $allctypes = array();
            //print_r($allctype);
            foreach ($allctype as $akey => $aval) {

                $allctypes[$aval->ctype_id] = array($aval->ctype_name, $aval->ctype_icon);
            }
            $allctypes = json_encode($allctypes);

            $languageData = \App\Modules\Admin\Models\Languages::all()->where('is_delete', 0);
            //languages 
            $languages = DB::table('lang_mapping')
//                            ->select('languages.*')
                            ->where('lang_mapping.module_mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'lang_mapping.module_mapping_type_id', 'doctors.id')
                            ->leftjoin('languages', 'languages.id', 'lang_mapping.lang_mapping_id')
                            ->get()->toArray();
            $languageList = [];
            if ($languages) {
                foreach ($languages as $langInfo) {
                    $languageList[] = trim($langInfo->lang_mapping_id);
                }
            }

            //specialization 
            $specialization = DB::table('specialization_mapping')
                            ->select('specialization_types.specialization_shortcode')
                            ->where('specialization_mapping.mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'specialization_mapping.mapping_type_id', 'doctors.id')
                            ->leftjoin('specialization_types', 'specialization_types.id', 'specialization_mapping.specialization_id')
                            ->get()->toArray();

            //meta data 
            $metadata = DB::table('metatype_data')
                            ->select('metatype_data.mapping_type_data_value', 'doctor_metatypes.dmetaname')
                            ->where('metatype_data.mapping_type', 'Doctor')
                            ->where('doctors.doctorcode', $id)
                            ->leftjoin('doctors', 'metatype_data.mapping_type_id', 'doctors.id')
                            ->leftjoin('doctor_metatypes', 'doctor_metatypes.dmeta_id', 'metatype_data.mapping_type_data_id')
                            ->get()->toArray();


            $slotsquery = DB::table('slots')
                    ->select('slots.hospital_id', 'booking_start_time', 'slots.id as slotid', 'screen_id', 'hospital_name', 'shift', 'booking_date', 'booking_time_long', 'available_types')
                    ->where('slots.is_delete', '0')
                    ->where('slots.is_active', '1')
                    ->where('booking_date', '>=', date('d-m-Y'))
                    ->where('doctors.doctorcode', $id)
                    // ->groupBy('slot_configurations.hospital_id')
                    ->leftjoin('doctors', 'slots.doctor_id', 'doctors.id')
                    ->leftjoin('hospitals', 'slots.hospital_id', 'hospitals.hospital_id');

            if (isset($_REQUEST['h']) && $_REQUEST['h'] != '') {
                $slotsquery->where('slots.hospital_id', $_REQUEST['h']);
            }
            
            $doctorMetaTypes = \App\Modules\Admin\Models\DoctorMetaTypes::all()->where('is_active', 1)->where('is_delete', 0);
            $docMetaData = \App\Modules\Admin\Models\MetatypeData::leftjoin('doctors', 'doctors.id', '=', 'metatype_data.mapping_type_id')
                    ->where('metatype_data.mapping_type', 'Doctor')
                    ->where('doctors.doctorcode', $id)->get()->all();
            $docMetaList = [];
            if ($docMetaData) {
                foreach ($docMetaData as $docMetaInfo) {
                    $docMetaList[$docMetaInfo->mapping_type_data_id] = $docMetaInfo->mapping_type_data_value;
                }
            }

            $slots = $slotsquery->get()->toArray();

            //echo "<pre>";                print_r($slots);exit;
            return view('Frontend::profile/editdoctorprofile')
                            ->with(compact('doctordata', 'consultations', 'languages', 'languageData', 'languageList', 'specialization', 'metadata', 'slots', 'allctypes'))
                    ->with(['doctorMetaTypes' => $doctorMetaTypes, 'docMetaList' => $docMetaList, 'doctorInfo' => $doctorInfo]);
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function filterParameters($params) {
        if (is_array($params)) {
            foreach ($params as $key => $value) {
                if (is_array($params[$key])) {
                    $params[$key] = self::filterParameters($value);
                }
                if (is_string($value)) {
                    $params[$key] = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
                }
            }
        }
        if (is_string($params))
            $params = htmlspecialchars($params, ENT_QUOTES, 'UTF-8');
        return $params;
    }

    public function updateDoctorProfile(Request $request) {
        try {
            $this->validate($request, [
                'firstname' => ['required', 'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'],
                'lastname' => ['required', 'regex:/^([a-zA-Z]+)(\s[a-zA-Z]+)*$/'],
                'dob' => 'required|date|before:today',
                'phonecode' => 'required',
                'phone' => 'required|unique:doctors,phone,' . $request->id,
                'email' => 'required|email|unique:doctors,email,' . $request->id,
                'licence' => 'required|digits_between:7,7|unique:doctors,licence,' . $request->id,
                'address_line1' => 'required|regex:/(^[-0-9A-Za-z.,\/ ]+$)/',
                'address_city' => 'required',
                'address_state' => 'required',
                'address_country' => 'required',
                'address_postcode' => 'required',
                    ], [
                'firstname.required' => 'First Name is required',
                'firstname.regex' => 'First Name format is invalid , use characters only',
                'lastname.regex' => 'Last Name format is invalid , use characters only',
                'dob.required' => 'Date of Birth is required',
                'dob.date' => '  Date of Birth is invalid,Use Date format',
                'dob.before' => 'The Date of Birth must be a date before today. ',
                'phonecode.required' => 'Phone Code is required',
                'phone.required' => 'Phone Number is required',
                'phone.unique' => 'Record already existing with same phone number',
                'email.required' => 'Email Address is required ',
                'email.unique' => 'Record already existing with same Email address',
                'licence.required' => 'Licence/GMC is required',
                'licence.digits_between' => 'Licence should be 7 numbers',
                'address_line1.required' => 'Address Line 1 is required',
                'address_line1.regex' => 'Invalid Address Line 1(Allowed /.,-)',
                'address_city.required' => 'City is required',
                'address_country.required' => 'Country is required',
                'address_postcode.required' => 'Postal code is required',
            ]);
            $requestParams = $this->filterParameters($request->all());
            Log::info('we are herer '.__FUNCTION__.' '.__LINE__);
            Log::info($requestParams);
//            echo "<pre>";print_R($requestParams);die;
            $id = isset($requestParams['id']) ? $requestParams['id'] : 0;
            $max = DB::table('doctors')->max('id');
            if ($max == '') {
                $max = 1;
            } else {
                $max++;
            }
            if ($id != 0) {
                $doctors = Doctor::where('id', $id)->where('is_delete', 0)->first();
                // $doctors->doctorcode = $doctor_code;
                $doctors->title = $request->title;
                $doctors->firstname = $request->firstname;
                $doctors->lastname = $request->lastname;
//                    $doctors->phone = $request->phone;
                $doctors->phone = $request->phonecode . '-' . $request->phone;
                $doctors->email = $request->email;
                $doctors->licence = $request->licence;
//                $doctors->opt_clinic = $request->opt_clinic;
                // $doctors->password = Hash::make($request->email);
                $doctors->terms = $request->terms;
//                $doctors->gender = $request->gender;
                $doctors->dob = $request->dob;
                // $doctors->photo = $request->photo;

                if ($request->hasFile('photo')) {
                    if ($request->file('photo')->isValid()) {
                        try {
                            $this->validate($request, [
                                'photo' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                            ]);

                            $file = $request->file('photo');
                            $name = $file->getClientOriginalName();
                            $request->file('photo')->move("uploads", $name);
                            $doctors->photo = $name;
                        } catch (Illuminate\Filesystem\FileNotFoundException $e) {
                            
                        }
                    }
                }

                if ($request->hasFile('licence_file')) {
                    if ($request->file('licence_file')->isValid()) {
                        try {
                            $this->validate($request, [
                                'licence_file' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                            ]);

                            $file = $request->file('licence_file');
                            $name = $file->getClientOriginalName();
                            $request->file('licence_file')->move("uploads", $name);
                            $doctors->licence_file = $name;
                        } catch (Illuminate\Filesystem\FileNotFoundException $e) {
                            
                        }
                    }
                }

//                $doctors->summary = $request->summary;
                $doctors->address_line1 = $request->address_line1;
                $doctors->address_line2 = $request->address_line2;
//                $doctors->address_line3 = $request->address_line3;
                $doctors->address_city = $request->address_city;
                $doctors->address_state = $request->address_state;
                $doctors->address_country = $request->address_country;
                $doctors->address_postcode = $request->address_postcode;
//                $doctors->timezone = $request->timezone;
                // $doctors->address_address = $request->address_address;
                // $doctors->address_long = $request->address_long;

//                $doctors->activation_key = Hash::make($request->email);
                $doctors->visitor = $this->getUserIpAddr();
                $doctors->updated_by = $id;
                $doctors->save();
            }
//            if (isset($requestParams['specialization']) && count($requestParams['specialization']) > 0) {
//                foreach ($requestParams['specialization'] as $specilizationId) {
//                    if ($specilizationId > 0) {
//                        $specilizationDetails = SpecializationMapping::where('mapping_type', $this->_mapping_type)->where('mapping_type_id', $id)->where('specialization_id', $specilizationId)->get()->all();
//                        if (!$specilizationDetails) {
//                            $specilizationData = new SpecializationMapping();
//                            $specilizationData->mapping_type = $this->_mapping_type;
//                            $specilizationData->mapping_type_id = $id;
//                            $specilizationData->specialization_id = $specilizationId;
//                            $specilizationData->created_by = $this->_user_id;
//                            $specilizationData->updated_by = 0;
//                            $specilizationData->save();
//                        }
//                    }
//                }
//                $specializationList = SpecializationMapping::where('mapping_type', $this->_mapping_type)->where('mapping_type_id', $id)->get()->all();
//                foreach ($specializationList as $specializationInfo) {
//                    if (!in_array($specializationInfo->specialization_id, $requestParams['specialization'])) {
//                        $specializationInfo->delete();
//                    }
//                }
//            } else {
//                SpecializationMapping::where('mapping_type', $this->_mapping_type)->where('mapping_type_id', $id)->delete();
//            }
//            if (isset($requestParams['consultation_types']) && count($requestParams['consultation_types']) > 0) {
//                foreach ($requestParams['consultation_types'] as $consultationId) {
//                    if ($consultationId > 0) {
//                        $consultationDetails = ConsultationMapping::where('mapping_type', $this->_mapping_type)->where('mapping_type_id', $id)->where('consultation_id', $consultationId)->get()->all();
//                        if (!$consultationDetails) {
//                            $consultationData = new ConsultationMapping();
//                            $consultationData->mapping_type = $this->_mapping_type;
//                            $consultationData->mapping_type_id = $id;
//                            $consultationData->consultation_id = $consultationId;
//                            $consultationData->created_by = $this->_user_id;
//                            $consultationData->updated_by = 0;
//                            $consultationData->save();
//                        }
//                    }
//                }
//                $consultationData = ConsultationMapping::where('mapping_type', 'Doctor')->where('mapping_type_id', $id)->get()->all();
//                foreach ($consultationData as $consultationInfo) {
//                    if (!in_array($consultationInfo->consultation_id, $requestParams['consultation_types'])) {
//                        $consultationInfo->delete();
//                    }
//                }
//            } else {
//                ConsultationMapping::where('mapping_type', 'Doctor')->where('mapping_type_id', $id)->delete();
//            }
            if (isset($requestParams['languages']) && count($requestParams['languages']) > 0) {
                foreach ($requestParams['languages'] as $langId) {
                    if ($langId != '') {
                        $langDetails = \App\Modules\Admin\Models\LanguageMapping::where('module_mapping_type', 'Doctor')
                                        ->where('module_mapping_type_id', $id)
                                        ->where('lang_mapping_id', $langId)->get()->all();
                        if (!$langDetails) {
                            $langData = new \App\Modules\Admin\Models\LanguageMapping();
                            $langData->module_mapping_type = 'Doctor';
                            $langData->module_mapping_type_id = $id;
                            $langData->lang_mapping_id = $langId;
                            $langData->created_by = $id;
                            $langData->updated_by = 0;
                            $langData->save();
                        }
                    }
                }
            } else {
                \App\Modules\Admin\Models\LanguageMapping::where('module_mapping_type', 'Doctor')
                        ->where('module_mapping_type_id', $id)->delete();
            }
//            $doctorMetaTypes = \App\Modules\Admin\Models\DoctorMetaTypes::all();
//            $this->saveMetaTypeData($id, 'Doctor', $doctorMetaTypes, $requestParams, 'dmetaname', 'dmeta_id');
            return redirect()->back()->withSuccess('Updated successfully!');
//            return Redirect::to('/doctor-dashboard');
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
            return redirect()->back()->withError($ex->getMessage());
        }
    }
    
    public function updateDoctorMetaData(Request $request){
        try{
            $requestParams = $this->filterParameters($request->all());
//            $doctorMetaTypes = \App\Modules\Admin\Models\DoctorMetaTypes::all();
            $doctorId = $request->docId;
            $metaId = $request->metaId;
            $metaDataValue = $requestParams['metaValue'];
//            $this->saveMetaTypeData($id, 'Doctor', $doctorMetaTypes, $requestParams, 'dmetaname', 'dmeta_id');
            $metaData = \App\Modules\Admin\Models\MetatypeData::where('metatype_data.mapping_type', 'Doctor')
                    ->where('metatype_data.is_active', 1)
                    ->where('metatype_data.mapping_type_id', $doctorId)
                    ->where('metatype_data.mapping_type_data_id', $metaId)
                    ->first();
//            echo "<pre>";print_r($metaData);die;
            if ($metaData) {
                $metaData->mapping_type_data_value = $metaDataValue;
//                $metaData->updated_by = $this->_user_id;
                $metaData->save();
            } else {
                $metatypeData = new \App\Modules\Admin\Models\MetatypeData();
                $metatypeData->mapping_type = 'Doctor';
                $metatypeData->mapping_type_id = $doctorId;
                $metatypeData->mapping_type_data_id = $metaId;
                $metatypeData->mapping_type_data_value = $metaDataValue;
                $metatypeData->created_by = 1;
                $metatypeData->updated_by = 0;
                $metatypeData->save();
            }
            return json_encode(['status' => 'success', 'message' => 'Updated successfully!']);
        } catch (Exception $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
            return json_encode(['status' => 'falied', 'message' => 'Unable to updated']);
        }
    }
    
    public function getUserIpAddr() {
        $ipaddress = '';
        if (isset($_SERVER['HTTP_CLIENT_IP']))
            $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
        else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_X_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
        else if (isset($_SERVER['HTTP_FORWARDED_FOR']))
            $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
        else if (isset($_SERVER['HTTP_FORWARDED']))
            $ipaddress = $_SERVER['HTTP_FORWARDED'];
        else if (isset($_SERVER['REMOTE_ADDR']))
            $ipaddress = $_SERVER['REMOTE_ADDR'];
        else
            $ipaddress = 'UNKNOWN';
        return $ipaddress;
    }

    public function hospitalProfile_old(Request $request, $id) {
        try {
            $hspselect = ['*'];
            $hospitalInfo = Hospitals::select($hspselect)->where('hospitalcode', $id)->get()
                    ->first();
            return view('Frontend::profile/hospital_profile')
                            ->with('hospitalInfo', $hospitalInfo);
        } catch (ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
        //print_r($request->all());die;
        $key = $request->input('key');
        $docselect = ["id", DB::raw("CONCAT(title, ' ' ,firstname, ' ' ,lastname) as name"), 'doctorcode as code', 'phone', 'email', 'summary', 'photo', DB::raw("'Doctor' as type")];
        $doctors = Doctor::select($docselect)->where('firstname', 'ilike', '%' . $key . '%')->orWhere('lastname', 'ilike', '%' . $key . '%')->get()
                ->all();

        $doctors = json_decode(json_encode($doctors));
        $hoselect = ["hospital_id as id", "hospital_name as name", 'hospitalcode as code', 'phone', 'email', 'summary', 'logo as photo', DB::raw("'Hospital' as type")];
        $hospitals = Hospitals::select($hoselect)->where('hospital_name', 'ilike', '%' . $key . '%')->get()
                ->all();
        $hospitals = json_decode(json_encode($hospitals));
        $result = array_merge($hospitals, $doctors);
        return view('Frontend::search')->with('result', $result);
    }

    public function getHospitalDoctorsList(Request $request) {

        try {
            $data = $request->all();
            $term = isset($data['term']) ? $data['term'] : '';
            $result = DB::select("SELECT id,name,label,code,category,type FROM view_home_search where LOWER(name) like LOWER('%" . $term . "%') ");
            /*
              $enc_result = array();
              foreach($result as $rk=>$rv){
              $rv->urlv = $this->customencrypt($rv->label);
              $enc_result[] =$rv;
              }


              //print_r($enc_result);exit;
              //return json_encode($enc_result); */
            return json_encode($result);
        } catch (\ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function getHospitalDoctorsList_NOTUSING(Request $request) {
        try {
            $data = $request->all();
            $term = isset($data['term']) ? $data['term'] : '';

            $grselect = ["group_id as id", "gid as code", "group_name as name", "group_name as label", DB::raw("'' as category"), DB::raw("'group' as type")];
            $groups = Groups::select($grselect)->where('group_name', 'ilike', '%' . $term . '%')->offset(0)
                    ->limit(10)
                    ->get()
                    ->all();
            $groups = json_decode(json_encode($groups));

            $docselect = ["id", DB::raw("CONCAT(title, ' ' ,firstname, ' ' ,lastname) as name"), DB::raw("CONCAT(title, ' ' ,firstname, ' ' ,lastname) as label"), 'doctorcode as code', DB::raw("'Doctors' as category"), DB::raw("'doctor' as type")];
            $doctors = Doctor::select($docselect)->where('firstname', 'ilike', '%' . $term . '%')->orWhere('lastname', 'ilike', '%' . $term . '%')
                    //->where('is_active',1)->where('is_verified',1)
                    ->offset(0)
                    ->limit(10)
                    ->get()
                    ->all();

            $doctors = json_decode(json_encode($doctors));
            $hoselect = ["hospital_id as id", "hospital_name as name", "hospital_name as label", 'hospitalcode as code', DB::raw("'Hospitals' as category"), DB::raw("'hospital' as type")];
            $hospitals = Hospitals::select($hoselect)->where('hospital_name', 'ilike', '%' . $term . '%')
                    //->where('is_active',1)->where('is_verified',1)
                    ->offset(0)
                    ->limit(10)
                    ->get()
                    ->all();
            $hospitals = json_decode(json_encode($hospitals));
            $result = array_merge($groups, $hospitals, $doctors);

            return json_encode($result);
        } catch (\ErrorException $ex) {
            Log::error($ex->getMessage() . ' ' . $ex->getTraceAsString());
        }
    }

    public function forgot() {
        return view('Frontend::forgot');
    }

    public function homecontactsave(Request $request) {
        $input = $request->all();
        $this->validate($request, ['firstname' => 'required', 'email' => 'required|email', 'description' => 'required'
                ], ['firstname.required' => 'First Name is required', 'email.required' => 'Emai Address is required ', 'description.required' => 'Message is required']);

        $check = true;
        // $check = Post::create($input);
        $input = $request->all();
        $user = Contact::create($input);
        \Mail::send('Frontend::contact_email', array(
            'firstname' => $request->get('firstname'),
            'lastname' => $request->get('lastname'),
            'phone' => $request->get('phone'),
            'email' => $request->get('email'),
            'description' => $request->get('description'),
                ), function ($message) use ($request) {
            $message->subject('Contact Information.');
            $message->from('admin@doctored.com');
            $message->to($request->email);
        });

        $arr = array('msg' => 'Something goes to wrong. Please try again lator', 'status' => false);
        if ($user) {
            $arr = array('msg' => 'Thank you for contacting us', 'status' => true);
        }

        return response()->json($arr);
    }

    public function contactus(Request $request) {

        if ($request->isMethod('post')) {

            //  dd($request);
            $this->validate($request, ['firstname' => 'required', 'phone' => 'phone:GB', 'email' => 'required|email', 'description' => 'required'
                    ], ['firstname.required' => 'First Name is required', 'phone.required' => 'Phone Number  is required', 'email.required' => 'Emai Address is required ', 'description.required' => 'Message is required']);

            $input = $request->all();
            $user = Contact::create($input);
            \Mail::send('Frontend::contact_email', array(
                'firstname' => $request->get('firstname'),
                'lastname' => $request->get('lastname'),
                'phone' => $request->get('phone'),
                'email' => $request->get('email'),
                'description' => $request->get('description'),
                    ), function ($message) use ($request) {
                $message->from('admin@doctored.dev');
                $message->to($request->email);
            });
            return back()
                            ->with('success', 'Thank you for contacting us!');
        }

        return view('Frontend::contactus');
    }

    public function show($page) {
        //
        $pagedata = DB::table('pages')->where('slug', $page)->first();
        if (isset($pagedata->id)) {
            $pid = $pagedata->id;
            $page_elements = DB::table('page_elements')->where('page_id', $pid)->get();
        } else {
            $page_elements = array();
        }
        //$page_elements = DB::table('page_elements')->where('slug',$page)->get();
        //Need to add logic to fetch all elements for the $slug
        return view('Frontend::show', ['pagedata' => $pagedata, 'page_elements' => $page_elements]);
    }

    public function customencrypt($str) {
        $str = str_replace('0', 'J', $str);
        $str = str_replace('1', 'Y', $str);
        $str = str_replace('2', 'Q', $str);
        $str = str_replace('3', 'K', $str);
        $str = str_replace('4', 'V', $str);
        $str = str_replace('5', 'U', $str);
        $str = str_replace('6', 'C', $str);
        $str = str_replace('7', 'T', $str);
        $str = str_replace('8', 'S', $str);
        $str = str_replace('9', 'N', $str);

        return $str;
    }
    
    public function managePrescription()
    {
        try{
            $doctorInfo = json_decode(json_encode(Auth::guard('doctor')->user()),1);
            return view('Frontend::bookingappointment/manage_prescription')->with(['doctorInfo' => $doctorInfo]);
        } catch (Exception $ex) {
            die('we are here');
            \Log::error($ex->getMessage());
            \Log::error($ex->getTraceAsString());
//            return $hospitalName;
        }
    }
    
    public function manageReports()
    {
        try{
            $doctorInfo = json_decode(json_encode(Auth::guard('doctor')->user()),1);
            return view('Frontend::bookingappointment/manage_reports')->with(['doctorInfo' => $doctorInfo]);
        } catch (Exception $ex) {
            die('we are here');
            \Log::error($ex->getMessage());
            \Log::error($ex->getTraceAsString());
//            return $hospitalName;
        }
    }
    
    public function doctorConsultation()
    {
        try{
            $doctorInfo = json_decode(json_encode(Auth::guard('doctor')->user()),1);
            return view('Frontend::bookingappointment/doctor_consultation')->with(['doctorInfo' => $doctorInfo]);
        } catch (Exception $ex) {
            die('we are here');
            \Log::error($ex->getMessage());
            \Log::error($ex->getTraceAsString());
//            return $hospitalName;
        }
    }

}

?>
