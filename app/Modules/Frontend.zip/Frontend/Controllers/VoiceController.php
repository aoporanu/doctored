<?php

namespace App\Modules\Frontend\Controllers;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Twilio\Rest\Client;
use Twilio\TwiML\VoiceResponse;

class VoiceController extends Controller
{
    public function __construct() {
	    // Twilio credentials
	    $this->account_sid = env('ACCOUNT_SID');
	    $this->auth_token = env('AUTH_TOKEN');

	    //The twilio number you purchased
	    $this->from = env('TWILIO_PHONE_NUMBER');

	    // Initialize the Programmable Voice API
	    $this->client = new Client($this->account_sid, $this->auth_token);
	 }

	public function initiateCall(Request $request) {
	    //Lookup phone number to make sure it is valid before initiating call
	    $phone_number = $request->phone_number;//$this->client->lookups->v1->phoneNumbers($request->phone_number)->fetch();

	    // If phone number is valid and exists
	    if($phone_number) {
	      // Initiate call and record call
	      $call = $this->client->account->calls->create(
	              $request->phone_number, // Destination phone number
	              $this->from, // Valid Twilio phone number
	              array(
	                "record" => True,
	                "url" => "http://demo.twilio.com/docs/voice.xml"));
//print_r($call);
	      if($call) {
	        echo 'Call initiated successfully';
	      } else {
	        echo 'Call failed!';
	      }
	   	
	   	}
  	}


  	    /**
     * Process a new call
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function newCall(Request $request)
    {
        $response = new VoiceResponse();
        $callerIdNumber = config('services.twilio')['number'];

        $dial = $response->dial(null, ['callerId'=>$this->from]);
        $phoneNumberToDial = $request->input('phone_number');

        if (isset($phoneNumberToDial)) {
            $dial->number($phoneNumberToDial);
        } else {
            $dial->client('support_agent');
        }

        return $response;
    }
}
