<?php 

namespace App\Modules\Frontend\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Redirect;
use View;
use Session;
use Illuminate\Support\Facades\DB;

use Auth;

class PatientDashboardController extends Controller {

	public function __construct()
    {
        $this->middleware('auth:patient');
    }

	public function patientDashboard() {
        //return view('Frontend::patient_dashboard');
		
		   $info = json_decode(json_encode(Auth::guard('patient')->user()),1);
    	return view('Frontend::patient_dashboard')
        ->with('info',$info);
    }
}