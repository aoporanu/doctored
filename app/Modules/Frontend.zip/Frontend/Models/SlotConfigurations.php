<?php
namespace App\Modules\Frontend\Models;

use Illuminate\Database\Eloquent\Model;

class SlotConfigurations extends Model {

    protected $table = 'slot_configurations';
   

}
