<?php
namespace App\Modules\Frontend\Models;

use Illuminate\Database\Eloquent\Model;

class States extends Model {

    protected $table = 'states';
   

}
