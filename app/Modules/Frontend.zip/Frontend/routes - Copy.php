<?php

$webMiddlewares = $middlewares = [
    \App\Http\Middleware\EncryptCookies::class,
    \Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse::class,
    \Illuminate\Session\Middleware\StartSession::class,
    \Illuminate\View\Middleware\ShareErrorsFromSession::class,
    \Illuminate\Routing\Middleware\SubstituteBindings::class,
];

Route::group(['middleware' => $middlewares], function () {

    Route::group(['namespace'=>'App\Http\Controllers\Auth'],function(){
        //Route::get('member-password-reset','ForgotPasswordController@showLinkRequestForm')->name('member.password.request');
        Route::post('member-password-email','ForgotPasswordController@sendResetLinkEmail')->name('member.password.email');
        Route::get('member-password/reset/{token}/{type?}','ResetPasswordController@showResetForm',function($id){

        })->name('member.password.reset')->defaults('type', 0);
        Route::post('member-password/reset','ResetPasswordController@reset')->name('member.password.update');

        //Route::get('doctor-password-reset','DoctorForgotPasswordController@showLinkRequestForm',)->name('doctor.password.request');
        Route::post('doctor-password-email','DoctorForgotPasswordController@sendResetLinkEmail')->name('doctor.password.email');
        Route::get('doctor-password/reset/{token}/{type?}','DoctorResetPasswordController@showResetForm')->name('doctor.password.reset')->defaults('type', 1);
        Route::post('doctor-password/reset','DoctorResetPasswordController@reset')->name('doctor.password.update');
    });


    Route::group(['namespace' => 'App\Modules\Frontend\Controllers'], function () {
        Route::any('/', 'IndexController@home');

        Route::view('/call', 'Frontend::call');
        Route::post('/callinit', 'VoiceController@initiateCall')->name('initiate_call');
        Route::post('/callinitn', 'VoiceController@newCall')->name('initiate_ncall');
      
        Route::any('/search', 'IndexController@search');

        Route::any('/register', 'RegisterController@register');
        Route::any('/register_doctor', 'RegisterController@register_doctor');

        Route::any('/forgot-password', 'IndexController@forgot');
        Route::any('/contact-us', 'IndexController@contactus');
        
        Route::any('/doctor-dashboard', 'DoctorDashboardController@doctorDashboard');

        Route::any('/clinic_info', 'DoctorDashboardController@clinicInfo');
        Route::any('/clinicsave', 'DoctorDashboardController@clinicSave');

        Route::any('/patient-dashboard', 'PatientDashboardController@patientDashboard');
        
        Route::any('/doctor-manage-slots', 'SlotConfigurationController@index');
        Route::any('/fetchdurations', 'SlotConfigurationController@fetchdurations');
        Route::any('/saveSlotConfiguration', 'SlotConfigurationController@saveSlotConfiguration');
          Route::any('/fetchSlotConfiguration', 'SlotConfigurationController@fetchSlotConfiguration');
      
        Route::any('/book-appointment', 'BookingAppointmentController@index');
        Route::post('/getappointmenttimes', 'BookingAppointmentController@getAppointmentTimes');
        Route::post('/create_appointment', 'BookingAppointmentController@createAppointment');


      // Route::post('contact-us','IndexController@saveContact');
      Route::any('/getCountries', 'CommonController@getCountries');
      Route::any('/getStates', 'CommonController@getStates');
      Route::any('/getStates/{id}', 'CommonController@getStates');
      

      Route::any('/getCities', 'CommonController@getCities');
      Route::any('/getCities/{id}', 'CommonController@getCities');

      Route::any('/testc', 'CommonController@testc');
      
      //Route::pattern('tags', '[0-9a-z]+');
        Route::get('/{slug}', array('as' => 'page.show', 'uses' => 'IndexController@show'));



    });

});

